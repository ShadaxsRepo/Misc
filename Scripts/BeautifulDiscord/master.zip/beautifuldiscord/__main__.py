from beautifuldiscord.app import main

main()
